In dit bestand zitten vier documenten:

1. STRI2012 XML Schema versie 2.0.0

Dit XML Schema hoort bij het STRI2012 v2.0 normdocument. In dit document is IMWE2014 toegevoegd. 
Dit XML Schema definieert zowel geleideformulier 2012 als Manifest 2012 conform dit concept.

Het schema is gepubliceerd op:
http://schemas.geonovum.nl/stri/2012/2.0/STRI2012.xsd

De verwijzing naar het schema op die URL is de officiele implementatie van STRI2012.

2. voorbeeld Manifest

Dit is een fictief voorbeeld Manifest conform het STRI2012 v2.0 normdocument 
en bijbehorend STRI2012 XML Schema versie 2.0.0. 
Het voorbeeld valideert tegen dit XML Schema. 
De weergegeven dossiers en plannen zijn puur illustratief. 
Dit voorbeeld is niet uitputtend wat betreft mogelijke attribuutwaarden. 
De elektronische handtekening in dit voorbeeld is niet valide.

3. voorbeeld 1: Geleideformulier; Bestemmingsplan

Dit is een fictief voorbeeld geleideformulier bestemmingsplan conform het STRI2012 v2.0 normdocument 
en bijbehorend STRI2012 XML Schema versie 2.0.0. 
Het voorbeeld valideert tegen dit XML Schema. 
Het weergegeven plan is puur illustratief. 
Dit voorbeeld is niet uitputtend wat betreft mogelijke attribuutwaarden. 
De elektronische handtekening in dit voorbeeld is niet valide.

4. voorbeeld 2: Geleideformulier; Welstandsnota

Dit is een fictief voorbeeld geleideformulier Welstandsnota conform het STRI2012 v2.0 normdocument 
en bijbehorend STRI2012 XML Schema versie 2.0.0. 
Het voorbeeld valideert tegen dit XML Schema. 
Het weergegeven plan is puur illustratief. 
Dit voorbeeld is niet uitputtend wat betreft mogelijke attribuutwaarden. 
De elektronische handtekening in dit voorbeeld is niet valide.